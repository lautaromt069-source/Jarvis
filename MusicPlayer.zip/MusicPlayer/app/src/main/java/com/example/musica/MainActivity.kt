package com.example.musica

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class MainActivity : Activity() {
    data class Item(val title: String, val uri: Uri, val video: Boolean)

    private val ACCENT = Color.parseColor("#A78BFA")
    private val all = ArrayList<Item>()
    private var shown = ArrayList<Item>()
    private var idx = -1
    private var player: MediaPlayer? = null
    private var rate = 1f
    private var keepPitch = false
    private val h = Handler(Looper.getMainLooper())

    private lateinit var vv: VideoView
    private lateinit var list: ListView
    private lateinit var nowTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: Button
    private lateinit var speedTv: TextView
    private lateinit var pitchBtn: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) scan()
        else requestPermissions(perms, 1)
        tick()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) scan()
        else Toast.makeText(this, "Sin permiso no puedo ver tu música", Toast.LENGTH_LONG).show()
    }

    private fun btn(t: String, w: Float = 1f, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false; setBackgroundColor(Color.parseColor("#2B2340"))
        layoutParams = LinearLayout.LayoutParams(0, -2, w).apply { setMargins(4, 4, 4, 4) }
        setOnClickListener { f() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0F0B1A")); setPadding(24, 70, 24, 16) }
        root.addView(row(
            TextView(this).apply { text = "🎵 Mi Música"; setTextColor(Color.WHITE); textSize = 22f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) },
            btn("🌐 Traducir", 0.6f) { translator() }))
        vv = VideoView(this)
        root.addView(vv, LinearLayout.LayoutParams(-1, 140))
        nowTv = TextView(this).apply { text = "Elige una canción"; setTextColor(ACCENT); textSize = 16f; gravity = Gravity.CENTER; setSingleLine(true) }
        root.addView(nowTv)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) vv.seekTo(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)
        timeTv = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(Color.GRAY); gravity = Gravity.CENTER }
        root.addView(timeTv)
        playBtn = btn("▶", 1.4f) { toggle() }
        root.addView(row(btn("⏮") { step(-1) }, playBtn, btn("⏭") { step(1) }))
        speedTv = TextView(this).apply { text = "Velocidad: 1.00x"; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        root.addView(speedTv)
        root.addView(row(btn("🐢 Slowed") { setRate(0.8f) }, btn("Normal") { setRate(1f) }, btn("🐇 Sped up") { setRate(1.25f) }))
        val sp = SeekBar(this).apply { max = 30; progress = 10 }
        sp.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) setRate(0.5f + p * 0.05f) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sp)
        pitchBtn = btn("Tono: cambia con la velocidad (efecto slowed)") { keepPitch = !keepPitch; updatePitchLabel(); applyRate() }
        root.addView(pitchBtn)
        val search = EditText(this).apply { hint = "Buscar…"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true) }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filter(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(search)
        list = ListView(this)
        list.setOnItemClickListener { _, _, i, _ -> play(i) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun updatePitchLabel() { pitchBtn.text = if (keepPitch) "Tono: original (sin efecto)" else "Tono: cambia con la velocidad (efecto slowed)" }

    private fun scan() {
        all.clear()
        fun q(base: Uri, nameCol: String, video: Boolean, sel: String?) {
            contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, nameCol), sel, null, "$nameCol ASC")?.use { c ->
                while (c.moveToNext()) {
                    val name = (c.getString(1) ?: "Sin título").substringBeforeLast('.')
                    all.add(Item((if (video) "🎬 " else "🎵 ") + name, ContentUris.withAppendedId(base, c.getLong(0)), video))
                }
            }
        }
        q(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, MediaStore.Audio.Media.TITLE, false, "${MediaStore.Audio.Media.IS_MUSIC}!=0")
        q(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, MediaStore.Video.Media.DISPLAY_NAME, true, null)
        filter("")
        if (all.isEmpty()) Toast.makeText(this, "No encontré música ni videos", Toast.LENGTH_LONG).show()
    }

    private fun filter(t: String) {
        shown = ArrayList(all.filter { it.title.contains(t, true) })
        list.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, shown.map { it.title }) {
            override fun getView(p: Int, v: View?, g: android.view.ViewGroup): View =
                super.getView(p, v, g).also { (it as TextView).setTextColor(if (p == idx) ACCENT else Color.WHITE) }
        }
    }

    private fun play(i: Int) {
        if (i !in shown.indices) return
        idx = i
        val it = shown[i]
        vv.layoutParams = vv.layoutParams.apply { height = if (it.video) 560 else 140 }
        nowTv.text = it.title
        vv.setOnPreparedListener { mp -> player = mp; vv.start(); applyRate(); seek.max = vv.duration }
        vv.setOnCompletionListener { step(1) }
        vv.setVideoURI(it.uri)
        playBtn.text = "⏸"
        (list.adapter as? ArrayAdapter<*>)?.notifyDataSetChanged()
    }

    private fun step(d: Int) { if (shown.isNotEmpty()) play(((if (idx < 0) 0 else idx) + d + shown.size) % shown.size) }

    private fun toggle() {
        if (idx < 0) { play(0); return }
        if (vv.isPlaying) { vv.pause(); playBtn.text = "▶" } else { vv.start(); applyRate(); playBtn.text = "⏸" }
    }

    private fun setRate(r: Float) { rate = r.coerceIn(0.5f, 2f); speedTv.text = "Velocidad: %.2fx".format(rate); applyRate() }

    private fun applyRate() {
        val p = player ?: return
        if (!vv.isPlaying) return
        try { p.playbackParams = PlaybackParams().setSpeed(rate).setPitch(if (keepPitch) 1f else rate) } catch (e: Exception) {}
    }

    private fun tick() {
        if (idx >= 0 && vv.duration > 0) {
            seek.progress = vv.currentPosition
            timeTv.text = "${fmt(vv.currentPosition)} / ${fmt(vv.duration)}"
        }
        h.postDelayed({ tick() }, 500)
    }

    private fun fmt(ms: Int) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

    private fun translator() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val inp = EditText(this).apply { hint = "Pega aquí el texto…"; minLines = 4 }
        val out = TextView(this).apply { textSize = 16f; setPadding(0, 20, 0, 0) }
        fun go(src: String, dst: String) {
            val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
            out.text = "Traduciendo… (la primera vez descarga el idioma, necesita internet)"
            t.downloadModelIfNeeded()
                .addOnSuccessListener { t.translate(inp.text.toString()).addOnSuccessListener { out.text = it }.addOnFailureListener { out.text = "No se pudo traducir." } }
                .addOnFailureListener { out.text = "No se pudo descargar el idioma. Revisa tu conexión." }
        }
        box.addView(inp)
        box.addView(row(btn("English → Español") { go(TranslateLanguage.ENGLISH, TranslateLanguage.SPANISH) },
            btn("Español → English") { go(TranslateLanguage.SPANISH, TranslateLanguage.ENGLISH) }))
        box.addView(out)
        AlertDialog.Builder(this).setTitle("Traductor").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Cerrar", null).show()
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
