package com.leb.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Environment
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.provider.MediaStore.Audio.Media as AM
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.util.concurrent.Executor

class MainActivity : Activity() {
    data class Song(val id: Long, val title: String, val artist: String, val album: String, val albumId: Long, val uri: Uri)
    data class Row(val t: String, val s: String, val song: Song? = null, val long: (() -> Unit)? = null, val click: () -> Unit)

    private val ACCENT = Color.parseColor("#8B6CFF")
    private val BG = Color.parseColor("#0E0E12")
    private val CARD = Color.parseColor("#1A1A22")
    private val GRAY = Color.parseColor("#9A9AA8")
    private val h = Handler(Looper.getMainLooper())
    private val songs = ArrayList<Song>()
    private val cache = LruCache<String, Bitmap>(60)
    private val prefs by lazy { getSharedPreferences("leb", MODE_PRIVATE) }
    private var ctrl: MediaController? = null
    private var tab = 0
    private var fKind = ""
    private var fVal = ""
    private var query = ""
    private var rows: List<Row> = emptyList()
    private var keepPitch = false
    private var rate = 1f
    private var sleepAt = 0L
    private var showLyrics = prefs.getBoolean("miapp_show_lyrics", true)
    private var lyricSize = prefs.getInt("miapp_lyric_size", 15).toFloat()
    private var lyricKeyword = prefs.getString("miapp_keyword", "miapp") ?: "miapp"
    private var autoFilterMiApp = prefs.getBoolean("miapp_auto_filter", false)

    private lateinit var list: ListView
    private lateinit var back: Button
    private lateinit var tabs: List<Button>
    private lateinit var mini: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniT: TextView
    private lateinit var miniS: TextView
    private lateinit var miniPlay: Button
    private lateinit var full: LinearLayout
    private lateinit var art: ImageView
    private lateinit var pT: TextView
    private lateinit var pS: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var pPlay: Button
    private lateinit var pShuf: Button
    private lateinit var pRep: Button
    private lateinit var favBtn: Button
    private lateinit var sleepBtn: Button
    private lateinit var speedTv: TextView
    private lateinit var lyricsPanel: LinearLayout
    private lateinit var lyricsTv: TextView
    private lateinit var settingsView: LinearLayout
    private lateinit var searchInput: EditText

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setSingleLine(true)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun btn(t: String, w: Float = 0f, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false; setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(if (w > 0) 0 else -2, -2, w); setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this).apply { setBackgroundColor(BG) }
        root.addView(buildMain()); root.addView(buildFull()); root.addView(buildSettings())
        setContentView(root)
        val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (hasAudioPerm()) scan()
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(perms, 1)
        connect()
        tick()
    }

    private fun hasAudioPerm() = checkSelfPermission(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (hasAudioPerm()) scan() else Toast.makeText(this, "Necesito permiso para ver tu música", Toast.LENGTH_LONG).show()
    }

    // ---------- Motor de música ----------
    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(m: MediaItem?, r: Int) { syncUi() }
        override fun onIsPlayingChanged(p: Boolean) { syncUi() }
        override fun onPlaybackStateChanged(s: Int) { syncUi() }
    }

    private fun connect() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        f.addListener({
            try { ctrl = f.get(); ctrl?.addListener(listener); syncUi() } catch (e: Exception) { Toast.makeText(this, "No se pudo iniciar el reproductor", Toast.LENGTH_LONG).show() }
        }, Executor { h.post(it) })
    }

    private fun art(s: Song) = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), s.albumId)

    private fun item(s: Song) = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).setArtworkUri(art(s)).build()).build()

    private fun playList(l: List<Song>, i: Int) {
        val c = ctrl ?: run { Toast.makeText(this, "Conectando…", Toast.LENGTH_SHORT).show(); return }
        c.setMediaItems(l.map { item(it) }, i, 0L); c.prepare(); c.play()
        applySpeed(); full.visibility = View.VISIBLE
    }

    private fun current(): Song? = ctrl?.currentMediaItem?.mediaId?.let { id -> songs.find { it.id.toString() == id } }

    private fun applySpeed() { ctrl?.setPlaybackParameters(PlaybackParameters(rate, if (keepPitch) 1f else rate)) }

    // ---------- Biblioteca ----------
    private fun scan() {
        songs.clear()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(base, arrayOf(AM._ID, AM.TITLE, AM.ARTIST, AM.ALBUM, AM.ALBUM_ID),
            "${AM.IS_MUSIC}!=0 AND ${AM.DURATION}>=30000 AND ${AM.DATA} NOT LIKE '%WhatsApp%'", null, "${AM.TITLE} COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artista desconocido"
                songs.add(Song(c.getLong(0), c.getString(1) ?: "Sin título", artist, c.getString(3) ?: "Álbum desconocido", c.getLong(4), ContentUris.withAppendedId(base, c.getLong(0))))
            }
        }
        refresh()
        if (songs.isEmpty()) Toast.makeText(this, "No encontré música en tu teléfono", Toast.LENGTH_LONG).show()
    }

    private fun favs(): MutableSet<String> = HashSet(prefs.getStringSet("fav", emptySet()) ?: emptySet())
    private fun isFav(s: Song?) = s != null && favs().contains(s.id.toString())
    private fun toggleFav(s: Song?) {
        if (s == null) return
        val set = favs()
        if (!set.remove(s.id.toString())) set.add(s.id.toString())
        prefs.edit().putStringSet("fav", set).apply()
        syncUi(); if (tab == 3) refresh() else list.invalidateViews()
    }

    private fun refresh() {
        tabs.forEachIndexed { i, b -> b.setTextColor(if (i == tab) ACCENT else GRAY) }
        back.visibility = if (fKind.isEmpty()) View.GONE else View.VISIBLE
        back.text = "‹ Volver   ·   $fVal"
        val q = query.trim()
        fun songRows(l: List<Song>) = l.mapIndexed { i, s -> Row(s.title, s.artist + if (isFav(s)) "  ♥" else "", s, { toggleFav(s) }) { playList(l, i) } }
        rows = when {
            tab == 1 && fKind.isEmpty() -> songs.groupBy { it.artist }.map { (k, v) -> Row(k, "${v.size} canciones") { fKind = "a"; fVal = k; tab = 0; refresh() } }
            tab == 2 && fKind.isEmpty() -> songs.groupBy { it.album }.map { (k, v) -> Row(k, "${v.first().artist} · ${v.size} canciones", v.first()) { fKind = "b"; fVal = k; tab = 0; refresh() } }
            tab == 3 -> songRows(songs.filter { isFav(it) })
            else -> songRows(songs.filter {
                val kwOk = !autoFilterMiApp || lyricKeyword.isBlank() || it.title.contains(lyricKeyword, true) || it.artist.contains(lyricKeyword, true) || it.album.contains(lyricKeyword, true)
                kwOk && (fKind.isEmpty() || (fKind == "a" && it.artist == fVal) || (fKind == "b" && it.album == fVal)) &&
                (q.isEmpty() || it.title.contains(q, true) || it.artist.contains(q, true))
            })
        }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val r = rows[p]
                val view = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(6), dp(16), dp(6))
                    addView(ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(CARD, 8); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }, LinearLayout.LayoutParams(dp(52), dp(52)))
                    addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0); addView(txt("", 15f, Color.WHITE)); addView(txt("", 12f, GRAY)) }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                val img = view.getChildAt(0) as ImageView
                val col = view.getChildAt(1) as LinearLayout
                (col.getChildAt(0) as TextView).apply { text = r.t; setTextColor(if (r.song != null && r.song.id == current()?.id) ACCENT else Color.WHITE) }
                (col.getChildAt(1) as TextView).text = r.s
                img.setImageDrawable(null); img.tag = null
                r.song?.let { thumb(it, img, 160) }
                view.setOnClickListener { r.click() }
                view.setOnLongClickListener { r.long?.invoke(); r.long != null }
                return view
            }
        }
    }

    private fun thumb(s: Song, iv: ImageView, size: Int) {
        val key = s.uri.toString() + size; iv.tag = key
        cache.get(key)?.let { iv.setImageBitmap(it); return }
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(s.uri, Size(size, size), null)
                cache.put(key, bm)
                runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (e: Exception) {}
        }.start()
    }

    // ---------- Interfaz ----------
    private fun buildMain(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(34), 0, 0) }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(8), dp(12), 0)
        }
        topBar.addView(txt("L.E.B-M", 28f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val settingsBtn = Button(this).apply {
            text = "⚙ Ajustes"
            textSize = 13f
            setTextColor(ACCENT)
            isAllCaps = false
            background = rounded(CARD, 10)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { openSettings() }
        }
        topBar.addView(settingsBtn)
        col.addView(topBar)
        val search = EditText(this).apply { hint = "Buscar canciones o artistas"; setHintTextColor(GRAY); setTextColor(Color.WHITE); setSingleLine(true); background = rounded(CARD, 12); setPadding(dp(14), dp(10), dp(14), dp(10)) }.also { searchInput = it }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s.toString(); tab = 0; refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(search, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(10), dp(16), dp(4)) })
        val bar = LinearLayout(this)
        tabs = listOf("Canciones", "Artistas", "Álbumes", "Favoritas").mapIndexed { i, n -> btn(n, 1f) { tab = i; fKind = ""; fVal = ""; refresh() }.apply { textSize = 13f } }
        tabs.forEach { bar.addView(it) }
        col.addView(bar)
        back = btn("‹ Volver") { fKind = ""; fVal = ""; refresh() }.apply { setTextColor(ACCENT); visibility = View.GONE }
        col.addView(back)
        list = ListView(this).apply { divider = null }
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        mini = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = rounded(CARD, 14); setPadding(dp(8), dp(8), dp(8), dp(8)); visibility = View.GONE }
        miniArt = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.parseColor("#2A2A35"), 8); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }
        mini.addView(miniArt, LinearLayout.LayoutParams(dp(46), dp(46)))
        val mc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        miniT = txt("", 15f, Color.WHITE, true); miniS = txt("", 12f, GRAY)
        mc.addView(miniT); mc.addView(miniS)
        mini.addView(mc, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = btn("▶") { togglePlay() }.apply { textSize = 22f }
        mini.addView(miniPlay)
        mini.setOnClickListener { full.visibility = View.VISIBLE }
        col.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), dp(4), dp(10), dp(10)) })
        return col
    }

    private fun buildFull(): View {
        full = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(22), dp(34), dp(22), dp(10)); visibility = View.GONE; isClickable = true }
        full.addView(btn("⌄  Cerrar") { full.visibility = View.GONE })
        art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(CARD, 20); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }
        full.addView(art, LinearLayout.LayoutParams(-1, dp(260)).apply { topMargin = dp(6) })
        pT = txt("", 22f, Color.WHITE, true).apply { setPadding(0, dp(16), 0, 0) }
        pS = txt("", 15f, GRAY)
        full.addView(pT); full.addView(pS)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) ctrl?.seekTo(p.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        full.addView(seek)
        timeTv = txt("0:00 / 0:00", 12f, GRAY).apply { gravity = Gravity.CENTER }
        full.addView(timeTv)
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pShuf = btn("🔀", 1f) { ctrl?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; syncUi() }
        pRep = btn("🔁", 1f) { ctrl?.let { it.repeatMode = (it.repeatMode + 1) % 3 }; syncUi() }
        pPlay = btn("▶", 1.3f) { togglePlay() }.apply { textSize = 32f; setTextColor(ACCENT) }
        ctl.addView(pShuf); ctl.addView(btn("⏮", 1f) { ctrl?.seekToPrevious() }.apply { textSize = 24f }); ctl.addView(pPlay)
        ctl.addView(btn("⏭", 1f) { ctrl?.seekToNext() }.apply { textSize = 24f }); ctl.addView(pRep)
        full.addView(ctl)
        speedTv = txt("Velocidad: 1.00x", 13f, Color.WHITE).apply { gravity = Gravity.CENTER }
        full.addView(speedTv)
        val sp = LinearLayout(this)
        sp.addView(btn("🐢 Slowed", 1f) { setRate(0.8f) }); sp.addView(btn("Normal", 1f) { setRate(1f) }); sp.addView(btn("🐇 Sped up", 1f) { setRate(1.25f) })
        full.addView(sp)
        val ex = LinearLayout(this).apply { gravity = Gravity.CENTER }
        favBtn = btn("♡", 1f) { toggleFav(current()) }.apply { textSize = 24f }
        sleepBtn = btn("⏲ Dormir", 1f) { sleepDialog() }
        ex.addView(favBtn); ex.addView(sleepBtn)
        ex.addView(btn("Tono", 1f) { keepPitch = !keepPitch; applySpeed(); Toast.makeText(this, if (keepPitch) "Tono original" else "El tono cambia con la velocidad", Toast.LENGTH_SHORT).show() })
        full.addView(ex)

        lyricsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 14)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = if (showLyrics) View.VISIBLE else View.GONE
        }
        val lHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val lTitle = txt("Letra · $lyricKeyword", 12f, ACCENT, true)
        lHeader.addView(lTitle, LinearLayout.LayoutParams(0, -2, 1f))
        val editLyricBtn = Button(this).apply {
            text = "Editar letra"
            textSize = 11f
            setTextColor(Color.WHITE)
            isAllCaps = false
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { current()?.let { showLyricEditor(it) } }
        }
        lHeader.addView(editLyricBtn)
        lyricsPanel.addView(lHeader)

        val lScroll = ScrollView(this)
        lyricsTv = TextView(this).apply {
            text = "Sin letra cargada para esta canción."
            textSize = lyricSize
            setTextColor(Color.WHITE)
            setLineSpacing(dp(4).toFloat(), 1.15f)
        }
        lScroll.addView(lyricsTv)
        lyricsPanel.addView(lScroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })
        full.addView(lyricsPanel, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        return full
    }

    private fun lyricKey(s: Song?) = if (s == null) "" else "miapp_lyric_${s.id}"

    private fun loadLyricText(s: Song?): String {
        if (s == null) return "Reproduce una canción para ver su letra."
        val custom = prefs.getString(lyricKey(s), null)
        if (!custom.isNullOrBlank()) return custom
        // Buscar archivo .lrc o .txt en carpetas comunes (incluyendo subcarpeta con palabra clave)
        val baseDirs = listOfNotNull(
            getExternalFilesDir(null),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        )
        val cleanName = s.title.replace(Regex("[\\/:*?\"<>|]"), "").trim()
        for (dir in baseDirs) {
            if (!dir.exists()) continue
            val candidates = listOf(
                File(dir, "$cleanName.lrc"),
                File(dir, "$cleanName.txt"),
                File(File(dir, lyricKeyword), "$cleanName.lrc"),
                File(File(dir, lyricKeyword), "$cleanName.txt")
            )
            val found = candidates.firstOrNull { it.exists() && it.canRead() }
            if (found != null) {
                return found.readText().lines().joinToString("\n") { line ->
                    line.replace(Regex("^\[[0-9:.]+\]\s*"), "")
                }.trim()
            }
        }
        return "Sin letra para \"${s.title}\" (${lyricKeyword}). Toca \"Editar letra\" para agregarla."
    }

    private fun refreshLyrics(s: Song?) {
        if (!::lyricsPanel.isInitialized || !::lyricsTv.isInitialized) return
        lyricsPanel.visibility = if (showLyrics) View.VISIBLE else View.GONE
        lyricsTv.textSize = lyricSize
        lyricsTv.text = loadLyricText(s)
    }

    private fun showLyricEditor(s: Song) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(6))
        }
        val input = EditText(this).apply {
            setText(prefs.getString(lyricKey(s), "") ?: "")
            hint = "Pega o escribe la letra (${lyricKeyword})..."
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Letra · ${s.title}")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putString(lyricKey(s), input.text.toString().trim()).apply()
                refreshLyrics(s)
                Toast.makeText(this, "Letra guardada", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Borrar") { _, _ ->
                prefs.edit().remove(lyricKey(s)).apply()
                refreshLyrics(s)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun buildSettings(): View {
        settingsView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(20), dp(34), dp(20), dp(16))
            visibility = View.GONE
            isClickable = true
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(btn("‹ Volver") { settingsView.visibility = View.GONE }.apply { setTextColor(ACCENT) })
        top.addView(txt("Ajustes · v1.1", 22f, Color.WHITE, true).apply { setPadding(dp(8), 0, 0, 0) })
        settingsView.addView(top)

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(24))
        }

        inner.addView(txt("LETRAS · MIAPP", 13f, ACCENT, true).apply { bottomMargin = dp(8) })

        val swLyrics = Switch(this).apply {
            text = "Mostrar letras en reproductor"
            setTextColor(Color.WHITE)
            isChecked = showLyrics
        }
        inner.addView(swLyrics, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val swFilter = Switch(this).apply {
            text = "Filtrar biblioteca con palabra clave"
            setTextColor(Color.WHITE)
            isChecked = autoFilterMiApp
        }
        inner.addView(swFilter, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        inner.addView(txt("Palabra clave / carpeta de letra:", 13f, GRAY).apply { bottomMargin = dp(4) })
        val kwInput = EditText(this).apply {
            setText(lyricKeyword)
            setTextColor(Color.WHITE)
            background = rounded(CARD, 10)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
        }
        inner.addView(kwInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val sizeLabel = txt("Tamaño de letra: ${lyricSize.toInt()}sp", 13f, Color.WHITE)
        inner.addView(sizeLabel, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        val seekSize = SeekBar(this).apply {
            max = 28
            progress = (lyricSize.toInt() - 10).coerceIn(0, 28)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val sp = p + 10
                    sizeLabel.text = "Tamaño de letra: \${sp}sp"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        inner.addView(seekSize, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        val saveBtn = Button(this).apply {
            text = "Guardar ajustes"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(ACCENT, 12)
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener {
                val chosenKw = kwInput.text.toString().trim().ifEmpty { "miapp" }
                val chosenSize = (seekSize.progress + 10).toFloat()
                showLyrics = swLyrics.isChecked
                autoFilterMiApp = swFilter.isChecked
                lyricKeyword = chosenKw
                lyricSize = chosenSize
                prefs.edit()
                    .putBoolean("miapp_show_lyrics", showLyrics)
                    .putBoolean("miapp_auto_filter", autoFilterMiApp)
                    .putString("miapp_keyword", lyricKeyword)
                    .putInt("miapp_lyric_size", lyricSize.toInt())
                    .apply()
                refreshLyrics(current())
                refresh()
                settingsView.visibility = View.GONE
                Toast.makeText(this@MainActivity, "Ajustes guardados (clave: $lyricKeyword)", Toast.LENGTH_SHORT).show()
            }
        }
        inner.addView(saveBtn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val rescanBtn = Button(this).apply {
            text = "Volver a escanear música"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(CARD, 12)
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener {
                if (hasAudioPerm()) scan() else Toast.makeText(this@MainActivity, "Sin permiso de audio", Toast.LENGTH_SHORT).show()
            }
        }
        inner.addView(rescanBtn, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(inner)
        settingsView.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return settingsView
    }

    private fun openSettings() {
        settingsView.visibility = View.VISIBLE
    }

    private fun setRate(r: Float) { rate = r; speedTv.text = "Velocidad: %.2fx".format(rate); applySpeed() }

    private fun togglePlay() { ctrl?.let { if (it.isPlaying) it.pause() else it.play() } }

    private fun sleepDialog() {
        val o = arrayOf("15 minutos", "30 minutos", "45 minutos", "1 hora", "Cancelar temporizador")
        val m = intArrayOf(15, 30, 45, 60, 0)
        AlertDialog.Builder(this).setTitle("Temporizador para dormir").setItems(o) { _, i ->
            sleepAt = if (m[i] == 0) 0L else System.currentTimeMillis() + m[i] * 60000L
            if (m[i] == 0) sleepBtn.text = "⏲ Dormir"
        }.show()
    }

    private fun syncUi() {
        val c = ctrl ?: return
        val s = current()
        mini.visibility = if (s != null) View.VISIBLE else View.GONE
        if (s != null && pT.text.toString() != s.title) {
            pT.text = s.title; pS.text = s.artist; miniT.text = s.title; miniS.text = s.artist
            art.setImageDrawable(null); miniArt.setImageDrawable(null)
            thumb(s, art, 600); thumb(s, miniArt, 160)
            refreshLyrics(s)
            list.invalidateViews()
        } else {
            refreshLyrics(s)
        }
        val icon = if (c.isPlaying) "⏸" else "▶"
        pPlay.text = icon; miniPlay.text = icon
        pShuf.alpha = if (c.shuffleModeEnabled) 1f else 0.4f
        pRep.alpha = if (c.repeatMode != Player.REPEAT_MODE_OFF) 1f else 0.4f
        pRep.text = if (c.repeatMode == Player.REPEAT_MODE_ONE) "🔂" else "🔁"
        favBtn.text = if (isFav(s)) "♥" else "♡"
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

    private fun tick() {
        val c = ctrl
        if (c != null && c.currentMediaItem != null) {
            val d = c.duration
            if (d > 0) { seek.max = d.toInt(); seek.progress = c.currentPosition.toInt(); timeTv.text = "${fmt(c.currentPosition)} / ${fmt(d)}" }
        }
        if (sleepAt > 0) {
            val left = sleepAt - System.currentTimeMillis()
            if (left <= 0) { sleepAt = 0; ctrl?.pause(); sleepBtn.text = "⏲ Dormir" } else sleepBtn.text = "⏲ ${left / 60000 + 1} min"
        }
        h.postDelayed({ tick() }, 500)
    }

    override fun onBackPressed() {
        when {
            ::settingsView.isInitialized && settingsView.visibility == View.VISIBLE -> settingsView.visibility = View.GONE
            full.visibility == View.VISIBLE -> full.visibility = View.GONE
            fKind.isNotEmpty() -> { fKind = ""; fVal = ""; refresh() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); ctrl?.release(); super.onDestroy() }
}
