# L.E.B-M v1.1

Reproductor de música local para Android 8.0+, compatible con **Android 12**.

## Cómo subir a GitHub

1. Descomprimí este ZIP.
2. Subí el **contenido** a la raíz del repo:
   - `gradlew`
   - `build.gradle`
   - `settings.gradle`
   - `app/`
   - `gradle/`
   - `.github/workflows/build.yml`
3. No subas el archivo `.zip` entero.
4. Push a `main` o `master`, o Actions → **Build L.E.B-M APK** → Run workflow.

El APK queda en Artifacts: **LEB-M-1.1-debug**.
