# L.E.B-M ProGuard rules
-keep class com.leb.player.** { *; }
