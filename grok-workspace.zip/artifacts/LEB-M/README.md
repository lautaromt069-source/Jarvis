# L.E.B-M  ·  v1.1

**L.E.B-M** es un reproductor de música local para Android, ligero, oscuro y con estilo propio.

Creado por **Lautaro Maldonado**.

---

## Características

- Biblioteca local (canciones, artistas, álbumes y favoritas)
- Buscador en tiempo real
- Mini-player + pantalla completa
- Shuffle, repetición, favoritos y temporizador para dormir
- Velocidad: Slowed / Normal / Sped up + opción de mantener tono
- **Letras con seguimiento (LRC)**  
  - Resalta la línea actual  
  - Auto-scroll  
  - Soporte de archivos `.lrc` / `.txt` o letras pegadas manualmente
- **Fondos animados** en el reproductor (gradientes suaves)
- Botón de **Ajustes** completo
- Sin publicidad · Sin tracking · 100 % offline

> Esta versión **no incluye** modo VIP ni banners exclusivos.

---

## Requisitos

- Android 8.0+ (API 26)
- Permiso de lectura de audio / almacenamiento

---

## Cómo compilar

### Con Android Studio
1. Clona el repositorio
2. Abre el proyecto en Android Studio
3. Espera a que Gradle sincronice
4. Ejecuta en un dispositivo o emulador

### Por línea de comandos
```bash
./gradlew assembleDebug
```
El APK queda en:
`app/build/outputs/apk/debug/app-debug.apk`

---

## Letras (cómo agregarlas)

1. **Desde la app**  
   Abre una canción → toca **Editar** en el panel de letras → pega el texto o el LRC completo.

2. **Con archivos**  
   Coloca un archivo `.lrc` o `.txt` con el mismo nombre de la canción en:
   - `/Music/`
   - `/Download/`
   - o dentro de una carpeta con el nombre de la **palabra clave** configurada en Ajustes (por defecto `miapp`)

Formato LRC ejemplo:
```
[00:12.50]Primera línea de la canción
[00:18.20]Segunda línea
[00:25.00]Tercera línea
```

---

## Ajustes disponibles

| Opción                        | Descripción                              |
|-------------------------------|------------------------------------------|
| Mostrar letras                | Activa/desactiva el panel de letras      |
| Filtrar con palabra clave     | Solo muestra canciones que coincidan     |
| Palabra clave / carpeta       | Nombre usado para buscar archivos .lrc   |
| Tamaño de letra               | De 10 a 38 sp                            |
| Fondos animados               | Gradientes animados en el reproductor    |

---

## Tecnologías

- Kotlin (UI 100 % programática)
- Media3 / ExoPlayer + MediaSession
- Material Design oscuro personalizado

---

## Licencia

Uso personal y educativo.  
Si querés publicar o modificar, mencioná el proyecto original.

---

**L.E.B-M v1.1** — Letras sincronizadas · Fondos animados · Hecho con ❤️
