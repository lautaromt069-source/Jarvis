package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val CYAN = Color.parseColor("#00D9FF")
    private val BG = Color.parseColor("#030B14")
    private val MODEL = "claude-sonnet-5-5"
    private val SYSTEM = "Eres JARVIS, el asistente personal del usuario: elegante, eficiente, con un toque de humor británico. " +
        "Responde siempre en español, en máximo 2 frases cortas, porque se leen en voz alta. Sin markdown ni emojis."

    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var mic: Button
    private lateinit var input: EditText
    private var recognizer: SpeechRecognizer? = null
    private val history = JSONArray()
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        buildUi()
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        if (prefs.getString("key", "").isNullOrEmpty()) askKey()
        reply("Sistemas en línea. A su servicio, señor.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(32, 80, 32, 24)
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S."; setTextColor(CYAN); textSize = 22f; letterSpacing = 0.3f; gravity = Gravity.CENTER
        })
        status = TextView(this).apply { text = "EN LÍNEA"; setTextColor(Color.parseColor("#4F8DA0")); gravity = Gravity.CENTER; textSize = 12f }
        root.addView(status)
        log = TextView(this).apply { setTextColor(Color.parseColor("#BFF6FF")); textSize = 16f; setLineSpacing(6f, 1f) }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 24 })

        mic = Button(this).apply {
            text = "🎤  HABLAR"; setTextColor(CYAN); setBackgroundColor(Color.parseColor("#06223A")); setOnClickListener { listen() }
        }
        root.addView(mic, LinearLayout.LayoutParams(-1, 150))

        input = EditText(this).apply {
            hint = "Escribe una orden…"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ ->
                val t = text.toString().trim(); text.clear(); if (t.isNotEmpty()) handle(t); true
            }
        }
        root.addView(input)
        setContentView(root)
    }

    override fun onInit(s: Int) { if (s == TextToSpeech.SUCCESS) tts.language = Locale("es", "ES") }

    private fun askKey() {
        val e = EditText(this).apply { hint = "sk-ant-..." }
        AlertDialog.Builder(this).setTitle("Clave de API de Anthropic").setView(e).setCancelable(false)
            .setPositiveButton("Guardar") { _, _ -> prefs.edit().putString("key", e.text.toString().trim()).apply() }.show()
    }

    private fun say(who: String, txt: String) { log.append("$who: $txt\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }
    private fun reply(txt: String) { say("JARVIS", txt); tts.speak(txt, TextToSpeech.QUEUE_FLUSH, null, "j") }

    // ---------- Voz ----------
    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { reply("Este dispositivo no tiene reconocimiento de voz."); return }
        tts.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "ESCUCHANDO…" }
                override fun onResults(r: Bundle?) {
                    status.text = "EN LÍNEA"
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                }
                override fun onError(e: Int) { status.text = "EN LÍNEA"; reply("No le he entendido, señor.") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            })
        }
    }

    // ---------- Órdenes ----------
    private fun handle(orden: String) {
        say("TÚ", orden)
        localCommand(orden.lowercase())?.let { reply(it); return }
        askClaude(orden)
    }

    private fun localCommand(o: String): String? {
        if (Regex("qu[eé] hora").containsMatchIn(o)) return "Son las " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + ", señor."
        if (Regex("qu[eé] d[ií]a|qu[eé] fecha").containsMatchIn(o))
            return "Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES")).format(Date()) + "."
        Regex("temporizador.*?(\\d+)\\s*(segundo|minuto)").find(o)?.let {
            val n = it.groupValues[1].toInt() * (if (it.groupValues[2] == "minuto") 60 else 1)
            startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, n).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Temporizador iniciado."
        }
        Regex("^busca\\s+(.+)").find(o)?.let {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1]))))
            return "Buscando en la red."
        }
        Regex("^abre\\s+(.+)").find(o)?.let { m ->
            val name = m.groupValues[1].trim()
            val pm = packageManager
            val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            val launch = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            return if (launch != null) { startActivity(launch); "Abriendo $name." } else "No encuentro la aplicación $name."
        }
        return null
    }

    // ---------- Cerebro: Claude ----------
    private fun askClaude(orden: String) {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) { askKey(); return }
        status.text = "PROCESANDO…"
        history.put(JSONObject().put("role", "user").put("content", orden))
        Thread {
            val text = try {
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                val recent = JSONArray()
                for (i in maxOf(0, history.length() - 10) until history.length()) recent.put(history.get(i))
                val body = JSONObject().put("model", MODEL).put("max_tokens", 300).put("system", SYSTEM).put("messages", recent)
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val resp = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                if (c.responseCode !in 200..299) "Error ${c.responseCode}. Compruebe su clave de API."
                else JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
            } catch (e: Exception) { "No tengo conexión con mi núcleo, señor." }
            runOnUiThread {
                status.text = "EN LÍNEA"
                history.put(JSONObject().put("role", "assistant").put("content", text))
                reply(text)
            }
        }.start()
    }

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
}
