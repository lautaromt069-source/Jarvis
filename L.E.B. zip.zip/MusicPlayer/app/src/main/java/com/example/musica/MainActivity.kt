package com.example.musica

import android.Manifest
import android.app.*
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class KeepAlive : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("play", "Reproducción", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "play").setContentTitle("L.E.B M").setContentText("Reproduciendo")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)
        return START_STICKY
    }
}

class MainActivity : Activity() {
    data class Item(val title: String, val artist: String, val album: String, val uri: Uri, val video: Boolean)
    data class Row(val t: String, val s: String, val thumb: Item? = null, val long: (() -> Unit)? = null, val click: () -> Unit)

    private val GREEN = Color.parseColor("#1ED760")
    private val BG = Color.parseColor("#121212")
    private val GRAY = Color.parseColor("#B3B3B3")
    private val h = Handler(Looper.getMainLooper())
    private val items = ArrayList<Item>()
    private var queue: List<Item> = emptyList()
    private var idx = -1
    private var tab = 0
    private var fKind = ""
    private var fVal = ""
    private var rows: List<Row> = emptyList()
    private var mp: MediaPlayer? = null
    private var vmp: MediaPlayer? = null
    private var rate = 1f
    private var keepPitch = false
    private var shuffle = false
    private var repeat = 0
    private var serviceOn = false
    private val prefs by lazy { getSharedPreferences("m", MODE_PRIVATE) }
    private val cache = LruCache<String, Bitmap>(60)
    private var sleepAt = 0L
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var rev: PresetReverb? = null
    private var eqPreset = -1
    private var bassLevel = 0
    private var reverbOn = false
    private lateinit var headTv: TextView
    private lateinit var favBtn: Button
    private lateinit var sleepBtn: Button

    private lateinit var list: ListView
    private lateinit var back: Button
    private lateinit var mini: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniT: TextView
    private lateinit var miniS: TextView
    private lateinit var miniPlay: Button
    private lateinit var tabs: List<Button>
    private lateinit var player: LinearLayout
    private lateinit var art: ImageView
    private lateinit var vv: VideoView
    private lateinit var pTitle: TextView
    private lateinit var pArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var pPlay: Button
    private lateinit var pShuf: Button
    private lateinit var pRep: Button
    private lateinit var speedTv: TextView
    private lateinit var pitchBtn: Button

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this).apply { setBackgroundColor(BG) }
        root.addView(buildMain()); root.addView(buildPlayer())
        setContentView(root)
        val media = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (media.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) scan()
        val ask = if (Build.VERSION.SDK_INT >= 33) media + Manifest.permission.POST_NOTIFICATIONS else media
        if (ask.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(ask, 1)
        tick()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        val ok = if (Build.VERSION.SDK_INT >= 33) checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (ok) scan() else Toast.makeText(this, "Sin permiso no puedo ver tu música", Toast.LENGTH_LONG).show()
    }

    // ---------- Interfaz ----------
    private fun btn(t: String, w: Float = 0f, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false; setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(if (w > 0) 0 else -2, -2, w); setOnClickListener { f() }
    }

    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setSingleLine(true)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun buildMain(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(34), 0, 0) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(8), dp(8), 0) }
        headTv = txt("Canciones", 26f, Color.WHITE, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        head.addView(headTv)
        head.addView(btn("🌐") { translator() })
        col.addView(head)
        back = btn("‹ Volver") { fKind = ""; fVal = ""; refresh() }.apply { setTextColor(GREEN); visibility = View.GONE }
        col.addView(back)
        list = ListView(this).apply { divider = null }
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        mini = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.parseColor("#2A2A2A")); setPadding(dp(8), dp(6), dp(8), dp(6)); visibility = View.GONE }
        miniArt = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#3A3A3A")) }
        mini.addView(miniArt, LinearLayout.LayoutParams(dp(46), dp(46)))
        val mc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        miniT = txt("", 15f, Color.WHITE, true); miniS = txt("", 12f, GRAY)
        mc.addView(miniT); mc.addView(miniS)
        mini.addView(mc, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = btn("▶") { toggle() }.apply { textSize = 22f }
        mini.addView(miniPlay)
        mini.setOnClickListener { player.visibility = View.VISIBLE }
        col.addView(mini)

        val bar = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#0A0A0A")) }
        val names = listOf("🎵", "🎤", "💿", "🎬", "❤️", "📁")
        tabs = names.mapIndexed { i, n -> btn(n, 1f) { tab = i; fKind = ""; fVal = ""; refresh() }.apply { textSize = 20f } }
        tabs.forEach { bar.addView(it) }
        col.addView(bar)
        return col
    }

    private fun buildPlayer(): View {
        player = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#3A2F5C"), BG)); setPadding(dp(20), dp(28), dp(20), dp(8)); visibility = View.GONE; isClickable = true }
        player.addView(btn("⌄ Cerrar") { player.visibility = View.GONE })
        val fr = FrameLayout(this)
        art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.parseColor("#2A2A2A"), 14); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }
        vv = VideoView(this).apply { visibility = View.GONE }
        fr.addView(art, FrameLayout.LayoutParams(-1, -1)); fr.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        player.addView(fr, LinearLayout.LayoutParams(-1, dp(240)).apply { topMargin = dp(4) })
        pTitle = txt("", 22f, Color.WHITE, true).apply { setPadding(0, dp(14), 0, 0) }
        pArtist = txt("", 15f, GRAY)
        player.addView(pTitle); player.addView(pArtist)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) seekTo(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        player.addView(seek)
        timeTv = txt("0:00 / 0:00", 12f, GRAY).apply { gravity = Gravity.CENTER }
        player.addView(timeTv)
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pShuf = btn("🔀", 1f) { shuffle = !shuffle; pShuf.alpha = if (shuffle) 1f else 0.4f }.apply { alpha = 0.4f }
        pPlay = btn("▶", 1.3f) { toggle() }.apply { textSize = 30f; setTextColor(GREEN) }
        pRep = btn("🔁", 1f) { repeat = (repeat + 1) % 3; pRep.text = if (repeat == 2) "🔂" else "🔁"; pRep.alpha = if (repeat > 0) 1f else 0.4f }.apply { alpha = 0.4f }
        ctl.addView(pShuf); ctl.addView(btn("⏮", 1f) { step(-1) }.apply { textSize = 24f }); ctl.addView(pPlay)
        ctl.addView(btn("⏭", 1f) { step(1) }.apply { textSize = 24f }); ctl.addView(pRep)
        player.addView(ctl)
        speedTv = txt("Velocidad: 1.00x", 13f, Color.WHITE).apply { gravity = Gravity.CENTER }
        player.addView(speedTv)
        val sp = LinearLayout(this)
        sp.addView(btn("🐢 Slowed", 1f) { setRate(0.8f) }); sp.addView(btn("Normal", 1f) { setRate(1f) }); sp.addView(btn("🐇 Sped up", 1f) { setRate(1.25f) })
        player.addView(sp)
        pitchBtn = btn("Tono: cambia con la velocidad") { keepPitch = !keepPitch; pitchBtn.text = if (keepPitch) "Tono: original" else "Tono: cambia con la velocidad"; applyRate() }.apply { setTextColor(GRAY) }
        player.addView(pitchBtn)
        val ex = LinearLayout(this).apply { gravity = Gravity.CENTER }
        favBtn = btn("♡", 1f) { toggleFav() }.apply { textSize = 22f }
        sleepBtn = btn("⏲ Dormir", 1f) { sleepDialog() }
        ex.addView(favBtn); ex.addView(btn("＋ Lista", 1f) { addToPlaylist() }); ex.addView(sleepBtn); ex.addView(btn("🎚 Sonido", 1f) { soundDialog() })
        player.addView(ex)
        return player
    }

    // ---------- Biblioteca ----------
    private fun scan() {
        items.clear()
        fun q(base: Uri, cols: Array<String>, sel: String?, order: String, video: Boolean) {
            contentResolver.query(base, cols, sel, null, order)?.use { c ->
                while (c.moveToNext()) {
                    val title = (c.getString(1) ?: "Sin título").let { if (video) it.substringBeforeLast('.') else it }
                    val artist = if (video) "Video" else (c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artista desconocido")
                    val album = if (video) "" else (c.getString(3) ?: "Álbum desconocido")
                    items.add(Item(title, artist, album, ContentUris.withAppendedId(base, c.getLong(0)), video))
                }
            }
        }
        val a = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        q(a, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM),
            "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>=30000 AND ${MediaStore.Audio.Media.DATA} NOT LIKE '%WhatsApp%'",
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC", false)
        q(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME),
            null, "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE ASC", true)
        refresh()
        if (items.isEmpty()) Toast.makeText(this, "No encontré música ni videos", Toast.LENGTH_LONG).show()
    }

    private fun refresh() {
        tabs.forEachIndexed { i, b -> b.alpha = if (i == tab) 1f else 0.45f }
        headTv.text = listOf("Canciones", "Artistas", "Álbumes", "Videos", "Favoritas", "Listas")[tab]
        back.visibility = if (fKind.isEmpty()) View.GONE else View.VISIBLE
        back.text = "‹ Volver   ·   $fVal"
        val audio = items.filter { !it.video }
        rows = when {
            tab == 1 && fKind.isEmpty() -> audio.groupBy { it.artist }.map { (k, v) -> Row(k, "${v.size} canciones") { fKind = "a"; fVal = k; tab = 0; refresh() } }
            tab == 2 && fKind.isEmpty() -> audio.groupBy { it.album }.map { (k, v) -> Row(k, "${v.first().artist} · ${v.size} canciones") { fKind = "b"; fVal = k; tab = 0; refresh() } }
            tab == 4 -> items.filter { isFav(it) }.let { l -> l.mapIndexed { i, it -> Row(it.title, it.artist, it) { playQueue(l, i) } } }
            tab == 5 && fKind == "p" -> byUri(pls().optJSONArray(fVal) ?: JSONArray()).let { l -> l.mapIndexed { i, it -> Row(it.title, it.artist, it) { playQueue(l, i) } } }
            tab == 5 -> listOf(Row("＋ Nueva lista", "Crea una lista de reproducción") { newPlaylist() }) +
                pls().let { o -> o.keys().asSequence().toList().map { k -> Row(k, "${byUri(o.getJSONArray(k)).size} canciones", null, { askDelete(k) }) { fKind = "p"; fVal = k; refresh() } } }
            tab == 3 -> items.filter { it.video }.let { v -> v.mapIndexed { i, it -> Row(it.title, "Video", it) { playQueue(v, i) } } }
            else -> audio.filter { fKind.isEmpty() || (fKind == "a" && it.artist == fVal) || (fKind == "b" && it.album == fVal) }
                .let { l -> l.mapIndexed { i, it -> Row(it.title, it.artist, it) { playQueue(l, i) } } }
        }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val r = rows[p]
                val view = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(6))
                    addView(ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.parseColor("#2A2A2A"), 6); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }, LinearLayout.LayoutParams(dp(50), dp(50)))
                    addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0); addView(txt("", 15f, Color.WHITE)); addView(txt("", 12f, GRAY)) }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                val img = view.getChildAt(0) as ImageView
                val col = view.getChildAt(1) as LinearLayout
                (col.getChildAt(0) as TextView).apply { text = r.t; setTextColor(if (r.thumb != null && cur()?.uri == r.thumb.uri) GREEN else Color.WHITE) }
                (col.getChildAt(1) as TextView).text = r.s
                img.setImageDrawable(null); img.tag = null
                r.thumb?.let { thumbInto(it, img) }
                view.setOnClickListener { r.click() }
                view.setOnLongClickListener { r.long?.invoke(); r.long != null }
                return view
            }
        }
    }

    // ---------- Reproducción ----------
    private fun playQueue(l: List<Item>, i: Int) { queue = l; idx = i; start(); player.visibility = View.VISIBLE }

    private fun cur(): Item? = queue.getOrNull(idx)

    private fun start() {
        val it = cur() ?: return
        mp?.release(); mp = null; vmp = null; vv.stopPlayback()
        pTitle.text = it.title; pArtist.text = it.artist; miniT.text = it.title; miniS.text = it.artist
        mini.visibility = View.VISIBLE
        favBtn.text = if (isFav(it)) "♥" else "♡"
        loadArt(it, art); loadArt(it, miniArt)
        vv.visibility = if (it.video) View.VISIBLE else View.GONE
        art.visibility = if (it.video) View.GONE else View.VISIBLE
        if (it.video) {
            vv.setOnPreparedListener { m -> vmp = m; vv.start(); applyRate() }
            vv.setOnCompletionListener { onEnd() }
            vv.setOnErrorListener { _, _, _ -> Toast.makeText(this, "No se puede reproducir este video", Toast.LENGTH_SHORT).show(); true }
            vv.setVideoURI(it.uri)
        } else {
            mp = MediaPlayer().apply {
                setWakeMode(this@MainActivity, PowerManager.PARTIAL_WAKE_LOCK)
                setOnPreparedListener { start(); applyRate(); applyFx() }
                setOnCompletionListener { onEnd() }
                setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "No se puede reproducir esta canción", Toast.LENGTH_SHORT).show(); true }
                try { setDataSource(this@MainActivity, it.uri); prepareAsync() } catch (e: Exception) {}
            }
        }
        if (!serviceOn) { serviceOn = true; try { startForegroundService(Intent(this, KeepAlive::class.java)) } catch (e: Exception) {} }
    }

    private fun loadArt(it: Item, iv: ImageView) {
        iv.setImageDrawable(null)
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(it.uri, Size(600, 600), null)
                runOnUiThread { if (cur() === it) iv.setImageBitmap(bm) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun isVideo() = cur()?.video == true
    private fun playing() = if (isVideo()) vv.isPlaying else mp?.isPlaying == true
    private fun pos() = try { if (isVideo()) vv.currentPosition else mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    private fun dur() = try { if (isVideo()) vv.duration else mp?.duration ?: 0 } catch (e: Exception) { 0 }
    private fun seekTo(p: Int) { if (isVideo()) vv.seekTo(p) else mp?.seekTo(p) }

    private fun toggle() {
        if (cur() == null) return
        if (playing()) { if (isVideo()) vv.pause() else mp?.pause() } else { if (isVideo()) vv.start() else mp?.start(); applyRate() }
        updateIcons()
    }

    private fun onEnd() { if (repeat == 2) start() else step(1, true) }

    private fun step(d: Int, auto: Boolean = false) {
        if (queue.isEmpty()) return
        var n = if (shuffle && queue.size > 1) { var r: Int; do { r = (Math.random() * queue.size).toInt() } while (r == idx); r } else idx + d
        if (n >= queue.size) { if (repeat == 1 || !auto) n = 0 else { updateIcons(); return } }
        if (n < 0) n = queue.size - 1
        idx = n; start()
    }

    private fun setRate(r: Float) { rate = r; speedTv.text = "Velocidad: %.2fx".format(rate); applyRate() }

    private fun applyRate() {
        val m = (if (isVideo()) vmp else mp) ?: return
        try { if (m.isPlaying) m.playbackParams = PlaybackParams().setSpeed(rate).setPitch(if (keepPitch) 1f else rate) } catch (e: Exception) {}
    }

    private fun updateIcons() { val t = if (playing()) "⏸" else "▶"; pPlay.text = t; miniPlay.text = t }

    private fun fmt(ms: Int) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

    private fun tick() {
        if (sleepAt > 0) {
            val left = sleepAt - System.currentTimeMillis()
            if (left <= 0) { sleepAt = 0; if (playing()) toggle(); sleepBtn.text = "⏲ Dormir" } else sleepBtn.text = "⏲ ${left / 60000 + 1} min"
        }
        if (cur() != null) {
            val d = dur(); val p = pos()
            if (d > 0) { seek.max = d; seek.progress = p; timeTv.text = "${fmt(p)} / ${fmt(d)}" }
            updateIcons()
        }
        h.postDelayed({ tick() }, 500)
    }

    // ---------- Extras: favoritos, listas, sueño, sonido ----------
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun thumbInto(m: Item, iv: ImageView) {
        val key = m.uri.toString(); iv.tag = key
        cache.get(key)?.let { iv.setImageBitmap(it); return }
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(m.uri, Size(160, 160), null)
                cache.put(key, bm)
                runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun favs(): MutableSet<String> = HashSet(prefs.getStringSet("fav", emptySet()) ?: emptySet())
    private fun isFav(m: Item?) = m != null && favs().contains(m.uri.toString())
    private fun toggleFav() {
        val c = cur() ?: return
        val set = favs()
        if (!set.remove(c.uri.toString())) set.add(c.uri.toString())
        prefs.edit().putStringSet("fav", set).apply()
        favBtn.text = if (isFav(c)) "♥" else "♡"
        if (tab == 4) refresh()
    }

    private fun pls(): JSONObject = JSONObject(prefs.getString("pl", "{}") ?: "{}")
    private fun savePls(o: JSONObject) = prefs.edit().putString("pl", o.toString()).apply()
    private fun byUri(a: JSONArray) = (0 until a.length()).mapNotNull { i -> items.find { it.uri.toString() == a.getString(i) } }

    private fun newPlaylist(then: (String) -> Unit = {}) {
        val e = EditText(this).apply { hint = "Nombre de la lista" }
        AlertDialog.Builder(this).setTitle("Nueva lista").setView(e)
            .setPositiveButton("Crear") { _, _ ->
                val n = e.text.toString().trim()
                if (n.isNotEmpty()) { val o = pls(); if (!o.has(n)) o.put(n, JSONArray()); savePls(o); then(n); refresh() }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun askDelete(k: String) {
        AlertDialog.Builder(this).setTitle("¿Eliminar la lista \"$k\"?")
            .setPositiveButton("Eliminar") { _, _ -> val o = pls(); o.remove(k); savePls(o); refresh() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun addToPlaylist() {
        val c = cur() ?: return
        val o = pls()
        val names = o.keys().asSequence().toList()
        fun add(n: String) {
            val a = o.getJSONArray(n); val u = c.uri.toString()
            if (byUri(a).none { it.uri.toString() == u }) a.put(u)
            savePls(o); Toast.makeText(this, "Añadida a $n", Toast.LENGTH_SHORT).show()
        }
        AlertDialog.Builder(this).setTitle("Añadir a lista").setItems((names + "＋ Nueva lista").toTypedArray()) { _, i ->
            if (i < names.size) add(names[i])
            else newPlaylist { n -> val o2 = pls(); o2.getJSONArray(n).put(c.uri.toString()); savePls(o2) }
        }.show()
    }

    private fun sleepDialog() {
        val opts = arrayOf("15 minutos", "30 minutos", "45 minutos", "1 hora", "Cancelar temporizador")
        val mins = intArrayOf(15, 30, 45, 60, 0)
        AlertDialog.Builder(this).setTitle("Temporizador para dormir").setItems(opts) { _, i ->
            sleepAt = if (mins[i] == 0) 0L else System.currentTimeMillis() + mins[i] * 60000L
            if (mins[i] == 0) sleepBtn.text = "⏲ Dormir"
        }.show()
    }

    private fun applyFx() {
        val m = mp ?: return
        try { eq?.release(); bass?.release(); rev?.release() } catch (e: Exception) {}
        eq = null; bass = null; rev = null
        try { eq = Equalizer(0, m.audioSessionId).also { it.setEnabled(true); if (eqPreset >= 0 && eqPreset < it.numberOfPresets) it.usePreset(eqPreset.toShort()) } } catch (e: Exception) {}
        try { bass = BassBoost(0, m.audioSessionId).also { it.setStrength(bassLevel.toShort()); it.setEnabled(bassLevel > 0) } } catch (e: Exception) {}
        try {
            if (reverbOn) {
                val r = PresetReverb(0, 0); r.setPreset(PresetReverb.PRESET_LARGEHALL); r.setEnabled(true); rev = r
                m.attachAuxEffect(r.id); m.setAuxEffectSendLevel(1f)
            }
        } catch (e: Exception) {}
    }

    private fun soundDialog() {
        if (isVideo() || mp == null) { Toast.makeText(this, "Reproduce una canción para usar el sonido", Toast.LENGTH_SHORT).show(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val sw = Switch(this).apply { text = "Reverb (sala grande)"; isChecked = reverbOn }
        sw.setOnCheckedChangeListener { _, c -> reverbOn = c; applyFx() }
        box.addView(sw)
        box.addView(TextView(this).apply { text = "Graves"; setPadding(0, dp(14), 0, 0) })
        val sb = SeekBar(this).apply { max = 1000; progress = bassLevel }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) { bassLevel = p; try { bass?.setStrength(p.toShort()); bass?.setEnabled(p > 0) } catch (e: Exception) {} }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb)
        val e = eq
        if (e != null) {
            val names = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) } + "Sin ecualizador"
            val cur = if (eqPreset in names.indices && eqPreset < names.size - 1) names[eqPreset] else "Sin ecualizador"
            box.addView(btn("Ecualizador: $cur") {
                AlertDialog.Builder(this).setTitle("Ecualizador").setItems(names.toTypedArray()) { _, i ->
                    eqPreset = if (i == names.size - 1) -1 else i; applyFx()
                }.show()
            })
        }
        AlertDialog.Builder(this).setTitle("Sonido").setView(box).setPositiveButton("Listo", null).show()
    }

    // ---------- Traductor ----------
    private fun translator() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val inp = EditText(this).apply { hint = "Pega aquí el texto…"; minLines = 4 }
        val out = TextView(this).apply { textSize = 16f; setPadding(0, dp(10), 0, 0) }
        fun go(src: String, dst: String) {
            val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
            out.text = "Traduciendo… (la primera vez descarga el idioma, necesita internet)"
            t.downloadModelIfNeeded()
                .addOnSuccessListener { t.translate(inp.text.toString()).addOnSuccessListener { out.text = it }.addOnFailureListener { out.text = "No se pudo traducir." } }
                .addOnFailureListener { out.text = "No se pudo descargar el idioma. Revisa tu conexión." }
        }
        val row = LinearLayout(this)
        row.addView(btn("English → Español", 1f) { go(TranslateLanguage.ENGLISH, TranslateLanguage.SPANISH) })
        row.addView(btn("Español → English", 1f) { go(TranslateLanguage.SPANISH, TranslateLanguage.ENGLISH) })
        box.addView(inp); box.addView(row); box.addView(out)
        AlertDialog.Builder(this).setTitle("Traductor").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Cerrar", null).show()
    }

    override fun onBackPressed() {
        when {
            player.visibility == View.VISIBLE -> player.visibility = View.GONE
            fKind.isNotEmpty() -> { fKind = ""; fVal = ""; refresh() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null); mp?.release()
        stopService(Intent(this, KeepAlive::class.java)); super.onDestroy()
    }
}
